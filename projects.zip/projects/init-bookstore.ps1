# init-bookstore.ps1
# Create local Node + SQLite project for bookstore

$root   = Join-Path $PSScriptRoot "bookstore-app"
$public = Join-Path $root "public"
$data   = Join-Path $root "data"

Write-Host "Creating folders..." -ForegroundColor Cyan
New-Item -ItemType Directory -Path $root   -Force | Out-Null
New-Item -ItemType Directory -Path $public -Force | Out-Null
New-Item -ItemType Directory -Path $data   -Force | Out-Null

Write-Host "Creating package.json..." -ForegroundColor Cyan
@'
{
  "name": "bookstore-local",
  "version": "1.0.0",
  "description": "Local bookstore inventory system (Node + SQLite)",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "author": "",
  "license": "MIT",
  "dependencies": {
    "better-sqlite3": "^9.0.0",
    "express": "^4.19.0"
  }
}
'@ | Set-Content -Path (Join-Path $root "package.json") -Encoding UTF8

Write-Host "Creating server.js..." -ForegroundColor Cyan
@'
const express = require('express');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const app = express();
const PORT = 3000;

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'bookstore.db');
const db = new Database(dbPath);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// DB init
db.exec(`
  CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barcode TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    author TEXT,
    publisher TEXT,
    price REAL,
    shelf TEXT,
    current_qty INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS sellers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    barcode TEXT UNIQUE NOT NULL,
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    seller_id INTEGER,
    movement_type TEXT NOT NULL,
    qty INTEGER NOT NULL,
    price REAL,
    note TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(book_id) REFERENCES books(id),
    FOREIGN KEY(seller_id) REFERENCES sellers(id)
  );
`);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', dbPath });
});

// create book
app.post('/api/books', (req, res) => {
  try {
    const { barcode, title, author, publisher, price, shelf, initialQty } = req.body;
    if (!barcode || !title) return res.status(400).json({ error: 'barcode and title required' });
    const stmt = db.prepare(`
      INSERT INTO books (barcode, title, author, publisher, price, shelf, current_qty)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(
      barcode.trim(),
      title.trim(),
      author ? author.trim() : null,
      publisher ? publisher.trim() : null,
      price ? Number(price) : null,
      shelf ? shelf.trim() : null,
      initialQty ? Number(initialQty) : 0
    );
    res.json({ success: true, id: info.lastInsertRowid });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// search books
app.get('/api/books/search', (req, res) => {
  const q = (req.query.q || '').trim();
  try {
    if (!q) {
      const rows = db.prepare(`
        SELECT id, barcode, title, author, publisher, price, shelf, current_qty
        FROM books
        ORDER BY created_at DESC
        LIMIT 50
      `).all();
      return res.json(rows);
    }
    const like = `%${q}%`;
    const rows = db.prepare(`
      SELECT id, barcode, title, author, publisher, price, shelf, current_qty
      FROM books
      WHERE
        barcode = @qExact
        OR title   LIKE @like
        OR author  LIKE @like
        OR publisher LIKE @like
        OR shelf   LIKE @like
      ORDER BY title
      LIMIT 200
    `).all({ qExact: q, like });
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// create seller
app.post('/api/sellers', (req, res) => {
  try {
    const { name, barcode } = req.body;
    if (!name || !barcode) return res.status(400).json({ error: 'name and barcode required' });
    const info = db.prepare(`
      INSERT INTO sellers (name, barcode)
      VALUES (?, ?)
    `).run(name.trim(), barcode.trim());
    res.json({ success: true, id: info.lastInsertRowid });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// stock in
app.post('/api/stock/in', (req, res) => {
  const { barcode, qty, note } = req.body;
  if (!barcode || !qty) return res.status(400).json({ error: 'barcode and qty required' });

  const qtyNum = Number(qty);
  if (!Number.isInteger(qtyNum) || qtyNum <= 0) {
    return res.status(400).json({ error: 'qty must be positive integer' });
  }

  const book = db.prepare(`SELECT id FROM books WHERE barcode = ?`).get(barcode.trim());
  if (!book) return res.status(404).json({ error: 'book not found' });

  const tx = db.transaction(() => {
    db.prepare(`UPDATE books SET current_qty = current_qty + ? WHERE id = ?`)
      .run(qtyNum, book.id);
    db.prepare(`
      INSERT INTO stock_movements (book_id, movement_type, qty, note)
      VALUES (?, 'IN', ?, ?)
    `).run(book.id, qtyNum, note || null);
  });
  tx();
  res.json({ success: true });
});

// sale
app.post('/api/stock/sale', (req, res) => {
  const { bookBarcode, sellerBarcode, qty, price } = req.body;
  const qtyNum = qty ? Number(qty) : 1;
  if (!bookBarcode || !sellerBarcode) {
    return res.status(400).json({ error: 'bookBarcode and sellerBarcode required' });
  }
  if (!Number.isInteger(qtyNum) || qtyNum <= 0) {
    return res.status(400).json({ error: 'qty must be positive integer' });
  }

  const book = db.prepare(`SELECT id, current_qty, title FROM books WHERE barcode = ?`)
    .get(bookBarcode.trim());
  if (!book) return res.status(404).json({ error: 'book not found' });
  if (book.current_qty < qtyNum) {
    return res.status(400).json({ error: 'not enough stock', current_qty: book.current_qty });
  }

  const seller = db.prepare(`SELECT id, name FROM sellers WHERE barcode = ? AND active = 1`)
    .get(sellerBarcode.trim());
  if (!seller) return res.status(404).json({ error: 'seller not found or inactive' });

  const tx = db.transaction(() => {
    db.prepare(`UPDATE books SET current_qty = current_qty - ? WHERE id = ?`)
      .run(qtyNum, book.id);
    db.prepare(`
      INSERT INTO stock_movements (book_id, seller_id, movement_type, qty, price, note)
      VALUES (?, ?, 'OUT', ?, ?, ?)
    `).run(book.id, seller.id, qtyNum, price ? Number(price) : null, null);
  });
  tx();
  res.json({
    success: true,
    bookTitle: book.title,
    sellerName: seller.name,
    qty: qtyNum
  });
});

app.listen(PORT, () => {
  console.log(`Bookstore app listening on http://localhost:${PORT}`);
});
'@ | Set-Content -Path (Join-Path $root "server.js") -Encoding UTF8

Write-Host "Creating setup.bat..." -ForegroundColor Cyan
@'
@echo off
echo ==========================================
echo  Bookstore Local - Setup
echo ==========================================

npm -v >NUL 2>&1
IF ERRORLEVEL 1 (
  echo ERROR: npm not found. Please install Node.js and try again.
  pause
  exit /b 1
)

echo Installing dependencies...
npm install

if not exist data (
  mkdir data
)

echo Running server...
npm start

pause
'@ | Set-Content -Path (Join-Path $root "setup.bat") -Encoding UTF8

Write-Host "Creating public/index.html..." -ForegroundColor Cyan
@'
<!doctype html>
<html lang="he" dir="rtl">
<head>
  <meta charset="utf-8" />
  <title>Bookstore Local</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body { font-family: Arial, sans-serif; margin: 1.5rem; }
    a { display: block; margin: 0.5rem 0; }
  </style>
</head>
<body>
  <h1>מערכת חנות ספרים - מקומית</h1>
  <p>בחר מסך:</p>
  <a href="/pos.html">עמדת מכירה (קופה)</a>
  <a href="/labels.html">הדפסת ברקודים</a>
</body>
</html>
'@ | Set-Content -Path (Join-Path $public "index.html") -Encoding UTF8

Write-Host ""
Write-Host ("Files and folders created in: " + $root) -ForegroundColor Green
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host ("1) cd `"$root`"") -ForegroundColor Yellow
Write-Host "2) run: setup.bat" -ForegroundColor Yellow
